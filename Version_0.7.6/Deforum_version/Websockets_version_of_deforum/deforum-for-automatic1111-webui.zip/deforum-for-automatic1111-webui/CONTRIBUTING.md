# Contributing

When contributing please ping the devs via Discord https://discord.gg/deforum to make sure you addition will fit well such a large project and to get help if needed.

*By contributing to this project you agree that your work will be granted copyright to Deforum LLC and licensed under the terms of the GNU Affero General Public License version 3.*
